How to install Camo Vest Pack:

1. Unzip files
2. copy folder "Camo Vest Pack" to:
   Steam\steamapps\common\PAYDAY2\assets\mod_overrides



How to uninstall Camo Vest Pack:

Only delete folder "Camo Vest Pack"



Camo Vest Pack replaces:

- Vest small for Payday gang
- Vest big for Payday gang


If you find any bugs or have any problems feel free to contact me.
You also can send me requests or advices for modifications you like. 
I will tell you if it�s possible and will implement it as soon as possible.

http://steamcommunity.com/id/the_real_brathoernchen

Please post your problem at my profile or add me (please comment  why you�re adding me).


Special Thanks:

Special thanks to Kamikaze94 for helping me with very helpful advices and tips ;-)


License:


No duplication, modification, or redistribution, without asking me.


